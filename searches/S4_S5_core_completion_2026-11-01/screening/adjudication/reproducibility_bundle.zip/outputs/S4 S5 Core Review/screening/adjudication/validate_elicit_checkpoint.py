"""Audit returned screening rows without manufacturing any semantic decisions."""
import argparse,csv,json,re
from collections import Counter
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('result');p.add_argument('--input',default='work/S4_S5_remaining_7188.csv');p.add_argument('--output',default='work/elicit_validation.json');a=p.parse_args()
def read(path):
 with open(path,encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f))
inputs=read(a.input);source={r['record_id']:r for r in inputs};rows=read(a.result)
allowed={'retain_for_fulltext','retain_secondary','retain_fulltext_unclear','exclude_title_abstract','exclude_nonresearch_component','exclude_core_keep_methods'}
counts=Counter(r.get('record_id','') for r in rows);errors=[]
def norm(s):return re.sub(r'\s+',' ',s).strip()
for r in rows:
 rid=r.get('record_id','');s=source.get(rid)
 if not s:errors.append([rid,'unknown_id']);continue
 if counts[rid]!=1:errors.append([rid,'duplicate_id'])
 if r.get('decision') not in allowed:errors.append([rid,'invalid_decision'])
 for k in ['reason','evidence_excerpt','abstract_adequacy','reviewer_method']:
  if not r.get(k,'').strip():errors.append([rid,'missing_'+k])
 evidence=r.get('evidence_excerpt','')
 if evidence and not any(evidence in s[k] for k in ['title','abstract']):
  errors.append([rid,'evidence_not_exact_literal' if not any(norm(evidence) in norm(s[k]) for k in ['title','abstract']) else 'evidence_whitespace_only_difference'])
 for k in ['title','doi']:
  if k in r and r[k]!=s[k]:errors.append([rid,k+'_changed'])
 if not s['abstract'].strip() and r.get('abstract_adequacy')=='substantive':errors.append([rid,'missing_abstract_marked_substantive'])
out={'input_count':len(inputs),'returned_rows':len(rows),'unique_returned_ids':len(counts),'missing_ids':[r['record_id'] for r in inputs if r['record_id'] not in counts],'decisions':dict(Counter(r.get('decision','') for r in rows)),'errors':errors,'semantic_accuracy_verified':False,'qualification':'Coverage and literal-evidence checks do not establish correctness of individual eligibility judgments.'}
Path(a.output).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in out.items() if k not in ['missing_ids','errors']},ensure_ascii=False));print('Missing:',len(out['missing_ids']),'Errors:',len(errors))
