import csv,json,hashlib,shutil
from pathlib import Path
ROOT=Path('outputs/Digital Twin Material Flow Review/bridge_searches')
OUT=ROOT/'fulltext_review'; OUT.mkdir(exist_ok=True)
rows=list(csv.DictReader((ROOT/'analysis/deduplicated_records.csv').open(encoding='utf-8-sig')))
core={3,6,8,12,14,27,36,40}
complement={25,29,31,34,41,42}
excluded={0:'Proceedings-volume record, not an individual study; mine individual papers separately.',1:'Proceedings-volume record, not an individual study.',7:'Business incubator and business-model focus; no operational stage transformation in abstract.',13:'Bibliometric/text-mining study, not an asset-data transformation.',17:'Railway circular-economy review outside building-stock bridge scope.',23:'Heritage scan-to-BIM documentation without material-inventory conversion demonstrated in abstract.',24:'AI circular-business tools rather than asset inventory/flow transformation.',26:'Adoption roadmap rather than implemented observation-to-inventory or inventory-to-flow method.',28:'Embankment-dam review outside building-stock scope.',30:'Downstream reuse decision/business model; no target bridge demonstrated.',38:'Railway-bridge maintenance outside building material-stock/turnover scope.'}
reasons={3:'Explicit GIS geometry to nested assemblies/elements/material quantities. Temporal flows are a supported use, not an executed probabilistic turnover model.',6:'Conceptual DT-material-passport integration directly addresses inventory continuity; retain separately from empirical implementations.',8:'CityGML to material composition/quantity and renovation/demolition timing: highest-priority direct B12/B23 candidate.',12:'Existing residential building surveys to structured BIM inventory and reusable components.',14:'Scan-to-BIM material intensity to GIS stocks; observed demolition change detection is an additional temporal connection.',27:'Condition observations to structured material inventory for selective reuse; digital twin is future development.',36:'BIM/BoQ to component/material bank visualization and disassembly attributes; no demonstrated probabilistic timing.',40:'BIM quantities feed structural/energy/material substitution scenarios; includes fixed replacement assumptions, not a stock-turnover uncertainty model.',25:'Complementary material sensing/classification method; no complete building stock bridge established.',29:'Complementary document-to-quantity/cost pipeline; downstream target is cost rather than material outflow.',31:'Implemented inventory and logistics data fusion; timed construction deliveries are distinct from building-stock turnover.',34:'Explicit probabilistic quantity/productivity-to-duration method and provenance controls; construction scheduling, not demolition turnover.',41:'Point clouds to counted/location-tagged precast pipes; infrastructure-site analogue for observation-to-inventory.',42:'CityGML production/quality architecture; no executed material mass/flow conversion.'}
bridges={3:'B12;B23 enabling only',6:'B12/B23 conceptual',8:'B12;B23 candidate',12:'B12',14:'B12;B23 retrospective event link',27:'B12 condition inventory',36:'B12 inventory representation',40:'B12;fixed replacement scenarios',25:'B12 sensing complement',29:'B12 quantity complement',31:'B12;construction-logistics B23 analogue',34:'construction-duration B23 analogue',41:'B12 infrastructure analogue',42:'S1 quality complement'}
files={3:'DTMFB-2394c459ec04.txt',12:'DTMFB-786eef4ce139.txt',14:'DTMFB-2c878ddf4181.txt',31:'DTMFB-f82bf5f38bf3.txt',34:'DTMFB-0e906b271b76-full.html',36:'DTMFB-f1a803053705.md',40:'DTMFB-8ac6d6a19330-full.html',41:'DTMFB-14cd06b4ebfd.txt',42:'DTMFB-e67012835c1e.txt'}
files.update({8:'DTMFB-7b8729bf813b.txt',25:'DTMFB-ba08181cf4ef.txt',29:'DTMFB-856d2825c306.txt'})
def write(name,rs):
 with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rs[0]));w.writeheader();w.writerows(rs)
screen=[]
for i,r in enumerate(rows):
 d=dict(r);d.update(screening_decision='retain_core' if i in core else 'retain_complement' if i in complement else 'exclude_from_bridge_synthesis' if i in excluded else 'background_only',decision_basis='title_abstract; targeted full-text methods/limitations check' if i in files else 'title_abstract',reason=reasons.get(i,excluded.get(i,'Review/conceptual/adoption context; no specific executed target-stage transformation established in abstract. Retain for background, not direct mechanism evidence.')),assessed_bridge=bridges.get(i,'not established'),fulltext_status='local_pdf' if (OUT/'local_pdfs'/f"{r['record_id']}.pdf").exists() else 'full_article_body_saved' if i in files else 'not_retrieved' if i in core|complement else 'not_sought_after_screening',reviewer='AI-assisted single screener',screening_date='2026-11-01')
 screen.append(d)
write('screening_43.csv',screen)
write('selected_14.csv',[r for r in screen if r['screening_decision'].startswith('retain')])
(OUT/'local_fulltext').mkdir(exist_ok=True)
manifest=[]
for i in sorted(core|complement):
 r=rows[i];rid=r['record_id']; p=OUT/'local_pdfs'/f'{rid}.pdf'
 if p.exists(): status='PDF_downloaded_verified';local=str(p.relative_to(OUT))
 elif i in files:
  src=Path('work/bridge_text')/files[i];p=OUT/'local_fulltext'/src.name;shutil.copyfile(src,p);status='HTML_article_body_saved_PDF_not_downloaded';local=str(p.relative_to(OUT))
 else: status='fulltext_pending';local=''
 manifest.append(dict(record_id=rid,title=r['title'],doi=r['doi'],status=status,local_path=local,sha256=hashlib.sha256(p.read_bytes()).hexdigest() if local else '',source_url='https://doi.org/'+r['doi'] if r['doi'] else 'https://archscience.org/wp-content/uploads/2023/03/6-A-parametric-approach-to-defining-archetypes-for-an-integrated-material-stocks-and-flows-analysis-and-life-cycle-assessment-of-built-stocks.pdf',access_note='Springer SLUB sign-in rejected; user handoff pending' if i in {6,8} else 'Publisher/author-search route did not yield downloadable full text yet' if not local else 'Full body available; targeted methods/results/limitations extraction. PDF and HTML statuses are distinct.'))
write('fulltext_manifest.csv',manifest)
summary={'input_records':len(rows),'core_retained':len(core),'complement_retained':len(complement),'background':43-len(core|complement)-len(excluded),'excluded':len(excluded),'selected_for_fulltext':len(core|complement),'pdf_downloaded':sum(r['status']=='PDF_downloaded_verified' for r in manifest),'html_body_saved':sum(r['status'].startswith('HTML') for r in manifest),'fulltext_pending':sum(r['status']=='fulltext_pending' for r in manifest)}
assert len(screen)==43 and len({r['record_id'] for r in screen})==43
assert sum(summary[k] for k in ['core_retained','complement_retained','background','excluded'])==43
(OUT/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8');print(json.dumps(summary))
