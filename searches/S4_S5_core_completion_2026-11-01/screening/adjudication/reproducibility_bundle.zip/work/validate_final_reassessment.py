import csv,io,json,zipfile
from pathlib import Path
P=Path('outputs/S4 S5 Core Review/screening/adjudication')
with zipfile.ZipFile(P.parent/'tables/all_records_screening.zip') as z:original=list(csv.DictReader(io.TextIOWrapper(z.open('all_records_screening.csv'),encoding='utf-8-sig')))
byid={r['record_id']:r for r in original}
reviews=json.loads((P/'title_abstract_decisions.json').read_text(encoding='utf-8'))
supp=json.loads((P/'supplemental_integrity_decisions.json').read_text(encoding='utf-8'))
queue={r['record_id'] for r in original if r['screening_status'] in ['retain_unclear','exclude_automated']}
assert set(reviews)==queue and len(reviews)==7238
assert not set(reviews)&set(supp)
for rid,v in {**reviews,**supp}.items():
 assert len(v['reason'])>20
 assert v['evidence'] in byid[rid]['title'] or v['evidence'] in byid[rid]['abstract'],rid
with zipfile.ZipFile(P/'revised_records.zip') as z:
 rows=list(csv.DictReader(io.TextIOWrapper(z.open('revised_records.csv'),encoding='utf-8-sig')))
 provenance=json.loads(z.read('merged_metadata_provenance.json'))
assert len(rows)==9587 and len({r['record_id'] for r in rows})==9587
ids=[rid for r in rows for rid in r['all_member_record_ids'].split(';')]
assert len(ids)==9918 and set(ids)==set(byid)
assert all(r['title']==byid[r['record_id']]['title'] for r in rows)
assert all('doi' in r and 'authors' in r and 'abstract' in r for r in rows)
resolutions=json.loads((P/'canonical_conflict_resolutions.json').read_text(encoding='utf-8'))
assert len(resolutions)==5
for rid,v in resolutions.items():
 r=next(r for r in rows if r['record_id']==rid)
 assert r['adjudication_status']==v['decision']
 assert v['evidence'] in r['title'] or v['evidence'] in r['abstract']
assert not any(r['adjudication_status']=='retain_conflicting_review_decisions' for r in rows)
log=list(csv.DictReader((P/'title_abstract_review_log.csv').open(encoding='utf-8-sig')))
assert len(log)==7239
assert all(r['doi']==byid[r['record_id']]['doi'] and r['title']==byid[r['record_id']]['title'] for r in log)
result={'requested_ids':7238,'remaining_request_completed':7188,'supplemental_ids':1,'missing_ids':0,'exact_evidence_validated':7239,'canonical_records':9587,'original_metadata_ids_preserved':9918,'passed':True}
(P/'final_validation.json').write_text(json.dumps(result,indent=2))
print(result)
