"""Integrate only actually returned Elicit decisions, preserving original decisions."""
import argparse,csv,json,hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('csv');p.add_argument('--require-complete',action='store_true');a=p.parse_args()
root=Path('outputs/S4 S5 Core Review/screening/adjudication')
with open('work/S4_S5_remaining_7188.csv',encoding='utf-8-sig',newline='') as f:inputs={r['record_id']:r for r in csv.DictReader(f)}
with open(a.csv,encoding='utf-8-sig',newline='') as f:rows=list(csv.DictReader(f))
ids=[r['record_id'] for r in rows];assert len(ids)==len(set(ids));assert set(ids)<=set(inputs)
if a.require_complete:assert set(ids)==set(inputs) and len(rows)==7188
allowed={'retain_for_fulltext','retain_secondary','retain_fulltext_unclear','exclude_title_abstract','exclude_nonresearch_component','exclude_core_keep_methods'}
for r in rows:
 s=inputs[r['record_id']];assert r['decision'] in allowed
 assert r['reason'].strip() and r['evidence_excerpt'].strip()
 assert r['evidence_excerpt'] in s['title'] or r['evidence_excerpt'] in s['abstract']
 assert r['title']==s['title'] and r['doi']==s['doi']
reviews=json.loads((root/'title_abstract_decisions.json').read_text(encoding='utf-8'))
sha=hashlib.sha256(Path(a.csv).read_bytes()).hexdigest()
for r in rows:
 rid=r['record_id'];v={'decision':r['decision'],'reason':r['reason'],'evidence':r['evidence_excerpt'],'stage_relevance':r['stage_relevance'],'abstract_adequacy':r['abstract_adequacy'],'reviewer_method':r['reviewer_method'],'review_source':'Elicit web research agent','source_csv_sha256':sha,'independent_human_review':'not performed','validation':'ID coverage, nonempty reasons, original metadata and exact literal evidence checked; this is not independent human validation'}
 if rid in reviews and reviews[rid].get('review_source')!='Elicit web research agent':raise ValueError('Would overwrite a previous independently authored decision: '+rid)
 reviews[rid]=v
(root/'title_abstract_decisions.json').write_text(json.dumps(reviews,ensure_ascii=False,indent=2),encoding='utf-8')
print('Integrated',len(rows),'Elicit decisions; total requested-row decisions',len(reviews))
