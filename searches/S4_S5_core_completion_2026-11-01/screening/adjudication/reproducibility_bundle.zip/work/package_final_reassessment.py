import json,zipfile,hashlib,shutil,csv,io
from pathlib import Path
P=Path('outputs/S4 S5 Core Review/screening/adjudication')
s=json.loads((P/'summary.json').read_text())
assert s['status']=='REQUESTED_REASSESSMENT_COMPLETE'
coverage=json.loads(Path('work/direct_review_coverage.json').read_text())
assert coverage['remaining_reviewed']==7188 and coverage['pending_original_ids']==0
with zipfile.ZipFile(P/'title_abstract_review_log.zip','w',zipfile.ZIP_DEFLATED) as z:z.write(P/'title_abstract_review_log.csv','title_abstract_review_log.csv')
shutil.copy('work/direct_review_coverage.json',P/'direct_review_coverage.json')
report=P/'PRISMA_REASSESSMENT.md'
report.write_text(report.read_text(encoding='utf-8')+'\n## Supplemental integrity checks\n\nOne additional original record outside the 7,238-ID queue was read and excluded for retraction. Three duplicate members were reread for QA but already belong to the main queue; they are not counted twice. These do not inflate requested-queue coverage. See supplemental_retraction_note.md and supplemental_integrity_decisions.json.\n',encoding='utf-8')
(P/'README.md').write_text('''# S4/S5 completed requested reassessment

All **7,188 remaining records** have now received title-and-complete-available-abstract decisions. Together with the prior 50, the requested queue contains **7,238/7,238 reviewed original IDs**, with zero pending. One supplemental retraction review is counted separately; three duplicate-member QA rereads do not add records.

This is AI-assisted title/abstract screening, not independent human review or completed full-text eligibility. Elicit delivered 80 records; all were reread and 14 decisions corrected. No paid upgrade was used. Three delegated assistants and the primary assistant completed the direct reading. Missing abstracts remain explicitly uncertain.

## Files

- `PRISMA_REASSESSMENT.md`: coverage, canonical outcome counts, method and limitations.
- `revised_records.zip`: `revised_records.csv` with 9,587 canonical records, all available bibliographic fields including authors, DOI, abstract and provenance; also original merged metadata JSON.
- `title_abstract_review_log.zip`: full CSV of 7,239 original-ID decisions, including bibliographic fields, individual reason, literal evidence and reviewer attribution.
- `title_abstract_decisions.json`: all 7,238 requested decisions; supplemental decisions in their separate JSON.
- `duplicate_group_adjudication.csv`, `record_alias_map.csv`, `IDENTIFIER_RESOLUTION.md`: all 330 groups and 14 DOI-conflict resolutions. 331 additional duplicates removed. One canonical DOI remains unverified/blank; original supplied values preserved.
- `summary.json`, `direct_review_coverage.json`, `prisma_reassessment_counts.csv`: machine-readable actual counts.
- `reproducibility_bundle.zip`: explicitly authored decision files and processing/validation code. Extract at the original review workspace root; source input is `outputs/S4 S5 Core Review/screening/tables/all_records_screening.zip` from this repository. Run work/aggregate_direct_reviews.py --require-complete, then adjudication/build_revision.py, then work/build_prisma_adjudication_report.py and work/package_final_reassessment.py. No model API or keyword classifier runs in these rebuilding scripts.

## Decision interpretation

Retained records need full-text eligibility; secondary literature is separate. Methods/background leads are preserved outside the S4/S5 core. Five differing decisions on merged records were explicitly reconciled after rereading; original decisions and reasons remain preserved in canonical_conflict_resolutions.json and the review log. The 2,680 previously automated scope/secondary records outside the requested queue are not claimed as newly read; only one documented supplemental record was added. Report counts and original-ID counts have different denominators.

Historical `revised_records_partial.zip`, `prisma_checkpoint.csv` and the old uncompressed 50-record CSV on GitHub are superseded by the files above, and remain only as checkpoints. No final included-study count is claimed.
''',encoding='utf-8')
with zipfile.ZipFile(P/'reproducibility_bundle.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in Path('work').glob('*.py'):
  if any(x in f.name for x in ['screen','prisma','aggregate_direct','package_final','review_elicit','validate_elicit','validate_final','save_b']):z.write(f,f.as_posix())
 for f in Path('work').glob('parallel_screen_*.json'):z.write(f,f.as_posix())
 for f in P.glob('*.py'):z.write(f,f.as_posix())
 for f in P.iterdir():
  if f.suffix in ['.json','.md','.csv','.txt','.xml'] and f.name not in ['final_manifest.json','title_abstract_review_log.csv']:
   z.write(f,f.as_posix())
files=['canonical_conflict_resolutions.json','duplicate_member_quality_checks.json','final_validation.json','README.md','PRISMA_REASSESSMENT.md','revised_records.zip','title_abstract_review_log.zip','title_abstract_decisions.json','summary.json','direct_review_coverage.json','prisma_reassessment_counts.csv','reproducibility_bundle.zip','build_revision.py','supplemental_integrity_decisions.json','supplemental_retraction_note.md','elicit_80_quality_review.json','elicit_80_root_overrides.json','elicit_checkpoint_80.csv']
manifest={n:{'bytes':(P/n).stat().st_size,'sha256':hashlib.sha256((P/n).read_bytes()).hexdigest(),'git_blob_sha':hashlib.sha1(b'blob '+str((P/n).stat().st_size).encode()+b'\0'+(P/n).read_bytes()).hexdigest()} for n in files}
(P/'final_manifest.json').write_text(json.dumps(manifest,indent=2))
Path('work/final_upload_files.json').write_text(json.dumps([str((P/n).resolve()) for n in files+['final_manifest.json']]))
print(json.dumps(s,indent=2))


