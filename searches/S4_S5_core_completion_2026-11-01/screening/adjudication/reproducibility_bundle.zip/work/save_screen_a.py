import csv,zipfile,io,json,sys
from pathlib import Path
with zipfile.ZipFile('outputs/S4 S5 Core Review/screening/tables/all_records_screening.zip') as z:
 rows=list(csv.DictReader(io.TextIOWrapper(z.open('all_records_screening.csv'),encoding='utf-8-sig')))
rows=[r for r in rows if r['screening_status'] in ['retain_unclear','exclude_automated']]
p=Path('work/parallel_screen_a.json')
out=json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}
for item in json.loads(Path(sys.argv[1]).read_text(encoding='utf-8')):
 i,d,reason,evidence,stage,*adequacy=item
 r=rows[i]
 assert evidence in r['title']+' '+r['abstract'],(i,evidence)
 out[r['record_id']]={'decision':d,'reason':reason,'evidence':evidence,'stage_relevance':stage,'abstract_adequacy':adequacy[0] if adequacy else 'substantive','reviewer_method':'assistant semantic title/complete-available-abstract reading; no independent human review'}
p.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(len(out))
