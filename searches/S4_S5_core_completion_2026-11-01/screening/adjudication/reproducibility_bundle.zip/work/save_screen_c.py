import json,sys,csv,zipfile,io
from pathlib import Path
with zipfile.ZipFile('outputs/S4 S5 Core Review/screening/tables/all_records_screening.zip') as z:
 rows=list(csv.DictReader(io.TextIOWrapper(z.open('all_records_screening.csv'),encoding='utf-8-sig')))
rows=[r for r in rows if r['screening_status'] in ['retain_unclear','exclude_automated']]
p=Path('work/parallel_screen_c.json'); out=json.loads(p.read_text(encoding='utf8')) if p.exists() else {}
for i,d,reason,evidence,stage,adequacy in json.loads(sys.stdin.read()):
 r=rows[i]
 assert evidence in r['title'] or evidence in r['abstract'],(i,evidence)
 out[r['record_id']]={'decision':d,'reason':reason,'evidence':evidence,'stage_relevance':stage,'abstract_adequacy':adequacy,'reviewer_method':'assistant semantic title/complete-available-abstract reading; no independent human review'}
p.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8')
print(len(out))
