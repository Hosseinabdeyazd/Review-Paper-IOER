import csv,zipfile,io,json,sys
from pathlib import Path
p=Path('outputs/S4 S5 Core Review/screening/tables/all_records_screening.zip')
with zipfile.ZipFile(p) as z:
 rows=list(csv.DictReader(io.TextIOWrapper(z.open('all_records_screening.csv'),encoding='utf-8-sig')))
rows=[r for r in rows if r['screening_status'] in ['retain_unclear','exclude_automated']]
for i in range(int(sys.argv[1]),min(int(sys.argv[2]),len(rows))):
 r=rows[i]
 print(json.dumps({'index':i,**{k:r[k] for k in ['record_id','title','abstract','screening_status']}},ensure_ascii=False))
