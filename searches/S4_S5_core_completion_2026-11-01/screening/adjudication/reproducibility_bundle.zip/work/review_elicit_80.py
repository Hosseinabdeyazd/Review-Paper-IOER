"""Root reassessment after reading all 80 complete supplied title/abstracts."""
import csv,json,io,zipfile
from pathlib import Path
P=Path('outputs/S4 S5 Core Review/screening/adjudication')
with zipfile.ZipFile(P.parent/'tables/all_records_screening.zip') as z:rows=list(csv.DictReader(io.TextIOWrapper(z.open('all_records_screening.csv'),encoding='utf-8-sig')))
rows=[r for r in rows if r['screening_status'] in ['retain_unclear','exclude_automated']]
overrides=[
(50,'retain_fulltext_unclear','S4','Explicitly weighs remodeling against replacement of an aging facility and its adaptability; retain to verify physical-retention criteria rather than exclude merely because environmental impacts are unstated.','whether to remodel or replace an aging facility'),
(54,'retain_fulltext_unclear','S4','Hospital planning explicitly considers continued adaptation of existing assets versus complete replacement; economic motivation does not rule out an S4 retention decision.','potential for adaptation and expansion of existing assets'),
(62,'retain_for_fulltext','S4','Describes conversion of an existing radwaste building instead of constructing a new one. This is explicit building reuse despite capital-cost motivation; radioactive-waste processing itself is not the inclusion basis.','modify an existing building at Dresden rather than construct a new one'),
(63,'retain_for_fulltext','S4','Describes adapting an existing radwaste building instead of constructing a new one. Building reuse, not the radioactive waste stream, supports S4 relevance.','modify an existing building at Dresden rather than construct a new one'),
(64,'retain_fulltext_unclear','S4','Regulatory constraints and technical evaluation for effective use of existing stock may govern rehabilitation/retention; full text needed to establish a material or reuse connection.','research needed to effectively use the existing building stock'),
(66,'exclude_nonresearch_component','unclear','This is a container-level overview of nine workshop papers rather than one research contribution. Preserve the volume as a route to its constituent rehabilitation papers; do not infer their individual ineligibility.','This workshop proceedings contains 9 papers'),
(67,'retain_fulltext_unclear','S4','Refurbishment of an existing shopping complex with lightweight additions plausibly retains structures; the short project summary does not establish the retention boundary, so full text is required.','revitalization of Maroochydore Shopping Complex'),
(71,'retain_fulltext_unclear','S4','Public/private intervention patterns specifically promote existing-stock rehabilitation; full text is needed to distinguish physical reuse/retention measures from finance-only policy discussion.','experiences of building and urban rehabilitation'),
(86,'retain_for_fulltext','S4','An existing 23-storey building is renovated for a new clothing-store use, including structural/logistical adaptations; explicit reuse is relevant even without an environmental calculation.','being renovated inside and out--and underneath--to house a New York clothing store'),
(93,'exclude_nonresearch_component','neither','A conference-volume description enumerates eight keynotes and 110 papers, not one study. Its thematic focus is urban groundwater, and individual constituent reports are not screened by this container decision.','A further 110 papers individually authored'),
(97,'retain_fulltext_unclear','S4','Compares inserting a dialysis function within an existing facility versus constructing a separate building, with regulatory barriers to reuse; full text needed to establish a reusable retention decision framework.','build within the physical confines of the existing SNF'),
(107,'exclude_core_keep_methods','background','National renovation activity, stock floor area and projected renovation rates provide stock-dynamics/renovation background; no direct recovery or embodied-impact result is stated.','continuous monitoring and cross-sectional studies of renovation'),
(110,'retain_fulltext_unclear','S4','Technical inspection is explicitly linked to altered loads and uses during industrial building modernization/reconstruction; it could establish suitability for continued reuse, requiring full text.','changes of load and conditions of operation of existing buildings'),
(112,'retain_fulltext_unclear','S5','Discusses conflict between fire-safety provisions and sustainability during building upgrades; the short abstract does not clarify whether constraints concern materials or only energy systems, so retain for clarification.','many of the recommended fire safety measures prevent buildings from meeting the criteria of being green and sustainable'),
]
rev={}
for i,d,stage,reason,e in overrides:
 r=rows[i];assert e in r['abstract'] or e in r['title']
 rev[r['record_id']]={'decision':d,'stage_relevance':stage,'reason':reason,'evidence':e,'abstract_adequacy':'book_level' if i in [66,93] else 'substantive','reviewer_method':'Elicit semantic screening followed by root full-title/abstract reassessment; no independent human review','review_source':'root reassessment of Elicit','queue_index':i}
(P/'elicit_80_root_overrides.json').write_text(json.dumps(rev,ensure_ascii=False,indent=2),encoding='utf-8')
(P/'elicit_80_quality_review.json').write_text(json.dumps({'all_full_available_titles_and_abstracts_reread':True,'record_ids':[r['record_id'] for r in rows[50:130]],'overrides':len(rev),'remaining_decisions':'confirmed after direct root reading; original individual rationale preserved','independent_human_reviewers':0,'not_a_representative_accuracy_sample':True},ensure_ascii=False,indent=2),encoding='utf-8')
print('80 full-text-at-abstract-level root checks; 14 explicit decision corrections recorded.')
