"""Validate explicitly authored decisions and combine them; never generates screening decisions."""
import csv,io,json,zipfile,hashlib,argparse
from pathlib import Path
from collections import Counter
p=argparse.ArgumentParser();p.add_argument('--require-complete',action='store_true');args=p.parse_args()
dest=Path('outputs/S4 S5 Core Review/screening/adjudication')
with zipfile.ZipFile(dest.parent/'tables/all_records_screening.zip') as z:
 rows=list(csv.DictReader(io.TextIOWrapper(z.open('all_records_screening.csv'),encoding='utf-8-sig')))
queue=[r for r in rows if r['screening_status'] in ('retain_unclear','exclude_automated')]
byid={r['record_id']:r for r in queue};indices={r['record_id']:i for i,r in enumerate(queue)}
base=json.loads((dest/'title_abstract_decisions.json').read_text(encoding='utf-8'))
# Restrict base to the original 50 and delivered Elicit 80; reruns rebuild newer decisions from source files.
out={rid:v for rid,v in base.items() if indices[rid]<130}
allowed={'retain_for_fulltext','retain_secondary','retain_fulltext_unclear','exclude_title_abstract','exclude_nonresearch_component','exclude_core_keep_methods'}
sources={};seen=set(out)
for filename in ['parallel_screen_root.json','parallel_screen_a.json','parallel_screen_b.json','parallel_screen_c.json']:
 f=Path('work')/filename;raw=f.read_bytes();data=json.loads(raw)
 sources[filename]={'records':len(data),'sha256':hashlib.sha256(raw).hexdigest()}
 for rid,v in data.items():
  assert rid in byid,(filename,'unknown ID',rid)
  assert rid not in seen,(filename,'overlap',rid)
  assert v['decision'] in allowed,(rid,'invalid decision')
  assert len(v.get('reason','').strip())>20,(rid,'missing reason')
  evidence=v.get('evidence','');r=byid[rid]
  assert evidence and (evidence in r['title'] or evidence in r['abstract']),(rid,'nonliteral evidence',evidence)
  out[rid]={**v,'queue_index':indices[rid],'review_source':v.get('review_source',filename.removesuffix('.json'))}
  seen.add(rid)
overrides=json.loads((dest/'elicit_80_root_overrides.json').read_text(encoding='utf-8'))
for rid,v in overrides.items():
 prior=out[rid];original=prior.get('original_elicit_decision',prior)
 out[rid]={**v,'original_elicit_decision':original}
missing=[r['record_id'] for r in queue if r['record_id'] not in out]
summary={'requested_original_ids':len(queue),'previously_reviewed':50,'remaining_requested':7188,
 'reviewed_original_ids':len(out),'remaining_reviewed':len(out)-50,'pending_original_ids':len(missing),
 'complete':not missing,'independent_human_review':False,'elicit_downloaded':80,'elicit_root_corrections':len(overrides),
 'decision_counts_original_ids':dict(Counter(v['decision'] for v in out.values())),'sources':sources}
Path('work/direct_review_coverage.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
Path('work/pending_review_ids.json').write_text(json.dumps(missing),encoding='utf-8')
if args.require_complete:assert not missing,f'{len(missing)} original records still pending'
(dest/'title_abstract_decisions.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
