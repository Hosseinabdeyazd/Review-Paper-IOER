import csv,sys,hashlib,json
from pathlib import Path
r=Path('outputs/S4 S5 Core Review/screening')
rows=list(csv.DictReader((r/'tables/all_records_screening.csv').open(encoding='utf-8-sig')))
kind=sys.argv[1]
items=[x for x in rows if x['decision_reason'].startswith(kind)]
items=sorted(items,key=lambda x:hashlib.sha256(('20261101'+x['record_id']).encode()).hexdigest())
start=int(sys.argv[2]) if len(sys.argv)>2 else 0
stop=int(sys.argv[3]) if len(sys.argv)>3 else 20
for x in items[start:stop]:
 print(json.dumps({k:x[k] for k in ['record_id','title','abstract','decision_reason']},ensure_ascii=False))
