import csv,zipfile,io,json,sys
from pathlib import Path
with zipfile.ZipFile('outputs/S4 S5 Core Review/screening/tables/all_records_screening.zip') as z:
 rows=list(csv.DictReader(io.TextIOWrapper(z.open('all_records_screening.csv'),encoding='utf-8-sig')))
rows=[r for r in rows if r['screening_status'] in ['retain_unclear','exclude_automated']]
p=Path('work/parallel_screen_b.json'); out=json.loads(p.read_text()) if p.exists() else {}
codes={'X':'exclude_title_abstract','R':'retain_for_fulltext','U':'retain_fulltext_unclear','M':'exclude_core_keep_methods','S':'retain_secondary','N':'exclude_nonresearch_component'}
for line in Path(sys.argv[1]).read_text(encoding='utf-8').splitlines():
 if not line.strip():continue
 i,c,stage,adequacy,evidence,reason=line.split('|')
 r=rows[int(i)]
 assert evidence in r['abstract'] or evidence in r['title'], (i,evidence)
 out[r['record_id']]={'decision':codes[c],'reason':reason,'evidence':evidence,'stage_relevance':stage,'abstract_adequacy':adequacy,'reviewer_method':'assistant semantic title/complete-available-abstract reading; no independent human review'}
p.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(len(out))
