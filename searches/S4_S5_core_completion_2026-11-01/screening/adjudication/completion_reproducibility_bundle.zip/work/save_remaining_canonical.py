import json,sys
from pathlib import Path
rows=json.loads(Path('work/remaining_canonical_2588.json').read_text(encoding='utf-8'))
p=Path('work/remaining_decisions_'+sys.argv[1]+'.json');out=json.loads(p.read_text(encoding='utf-8')) if p.exists() else {}
codes={'X':'exclude_title_abstract','R':'retain_for_fulltext','U':'retain_fulltext_unclear','M':'exclude_core_keep_methods','S':'retain_secondary','N':'exclude_nonresearch_component'}
for line in Path(sys.argv[2]).read_text(encoding='utf-8-sig').splitlines():
 if not line.strip():continue
 i,c,stage,adequacy,evidence,reason=line.split('|');r=rows[int(i)]
 assert evidence and (evidence in r['title'] or evidence in r['abstract']),(i,evidence)
 assert len(reason)>20
 out[r['record_id']]={'decision':codes[c],'reason':reason,'evidence':evidence,'stage_relevance':stage,'abstract_adequacy':adequacy,'queue_index':int(i),'reviewer_method':'assistant semantic title/complete-available-abstract reading; no independent human review','review_scope':'remaining canonical 2588'}
p.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8');print(len(out))
