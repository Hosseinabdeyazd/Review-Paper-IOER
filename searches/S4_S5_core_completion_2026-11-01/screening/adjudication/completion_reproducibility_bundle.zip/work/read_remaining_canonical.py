import json,sys
from pathlib import Path
rows=json.loads(Path('work/remaining_canonical_2588.json').read_text(encoding='utf-8'))
for i in range(int(sys.argv[1]),min(int(sys.argv[2]),len(rows))):
 r=rows[i];print(json.dumps({'index':i,**{k:r[k] for k in ['record_id','title','abstract','doi']}},ensure_ascii=False))
