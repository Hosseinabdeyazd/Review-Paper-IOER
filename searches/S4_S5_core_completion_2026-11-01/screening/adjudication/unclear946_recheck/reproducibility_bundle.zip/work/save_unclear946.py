import json,sys
from pathlib import Path
q=json.loads(Path('work/unclear946_queue.json').read_text(encoding='utf8'))
p=Path('work/unclear946_'+sys.argv[1]+'.json')
out=json.loads(p.read_text(encoding='utf8')) if p.exists() else {}
codes={'R':'retain_for_fulltext','U':'retain_fulltext_unclear','S':'retain_secondary','M':'exclude_core_keep_methods','X':'exclude_title_abstract','N':'exclude_nonresearch_component'}
for line in Path(sys.argv[2]).read_text(encoding='utf-8-sig').splitlines():
 if not line.strip():continue
 i,c,gap,evidence,reason=line.split('|');r=q[int(i)]
 assert evidence and (evidence in r['title'] or evidence in r['abstract']),(i,evidence)
 assert len(reason)>30 and gap
 out[r['record_id']]={'decision':codes[c],'reason':reason,'evidence':evidence,'remaining_information_gap':gap,'queue_index':int(i),'reviewer_method':'AI-assisted second reading of title and entire available abstract; no independent human review'}
p.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf8');print(len(out))
