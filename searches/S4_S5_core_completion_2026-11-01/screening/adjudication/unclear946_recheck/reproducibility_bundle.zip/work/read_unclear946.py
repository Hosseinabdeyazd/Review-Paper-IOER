import json,sys
from pathlib import Path
q=json.loads(Path('work/unclear946_queue.json').read_text(encoding='utf8'))
for i in range(int(sys.argv[1]),min(int(sys.argv[2]),len(q))):
 r=q[i]
 print(json.dumps({'index':i,**{k:r.get(k,'') for k in ['record_id','title','abstract','doi','adjudication_reason','completion_abstract_adequacy']}},ensure_ascii=False))
